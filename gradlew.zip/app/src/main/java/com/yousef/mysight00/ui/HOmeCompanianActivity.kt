package com.yousef.mysight00.ui

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.yousef.mysight00.R

class HOmeCompanianActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home_companian)
    }
}